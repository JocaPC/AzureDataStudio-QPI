# Change Log
All notable changes to the "Query Performance Insight" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

## 0.1.0
- Initial release